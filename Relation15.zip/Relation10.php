<?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */

$test = mysql_connect("localhost", "root", "Gayatri1987") or die (mysql_error());

mysql_select_db("university", $test);


#Query 1

echo "Table Section <br> <br>";

$sql = "SELECT * FROM Section;";

$result = mysql_query($sql, $test);

#CREATE TABLE Section(SecCourse char (10),
# Instructor char (20), 
#Semester INT, 
#Year INT, 
#SecNum INT, PRIMARY KEY (SecCourse));

echo "SecCourse char (10)" .str_repeat('&nbsp;', 5) . "Instructor char (20)" .str_repeat('&nbsp;', 5) . "Semester (INT)" .str_repeat('&nbsp;', 5) 
. "Year (INT)" .str_repeat('&nbsp;', 5) . "SecNum (INT)" .str_repeat('&nbsp;', 5) . "<br> <br>";


while($row = mysql_fetch_array($result))
{

$SecCourse = $row['SecCourse'];
$Instructor = $row['Instructor'];
$Semester = $row['Semester'];
$Year = $row['Year'];
$SecNum = $row['SecNum'];



echo $SecCourse . str_repeat('&nbsp;', 8). $Instructor . str_repeat('&nbsp;', 10). $Semester .str_repeat('&nbsp;', 10). $Year .str_repeat('&nbsp;', 15)
. $SecNum .str_repeat('&nbsp;', 8) ."<br>";

}

?>

























