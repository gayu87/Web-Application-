<?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */

$test = mysql_connect("localhost", "root", "Gayatri1987") or die (mysql_error());

mysql_select_db("university", $test);


#table Grade_Record

echo "Table Grade_Record <br> <br>";

$sql = "SELECT * FROM Grade_Record;";

$result = mysql_query($sql, $test);

#CREATE TABLE Grade_Record(SSN INT (9) REFERENCES Student(SSSN),
# SectionCourse char (10) REFERENCES Section (SecCourse),
# Grade char (2));

echo "SSN INT(9) " .str_repeat('&nbsp;', 5) . "SectionCourse char(10)" .str_repeat('&nbsp;', 5) . "Grade char (2)" .str_repeat('&nbsp;', 5) . "<br> <br>";


while($row = mysql_fetch_array($result))
{

$ssn = $row['SSN'];
$SectionCourse = $row['SectionCourse'];
$Grade = $row['Grade'];




echo $ssn . str_repeat('&nbsp;', 8). $SectionCourse . str_repeat('&nbsp;', 28). $Grade .str_repeat('&nbsp;', 10)."<br>";

}

?>

























