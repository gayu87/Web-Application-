<?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */

$test = mysql_connect("localhost", "root", "Gayatri1987") or die (mysql_error());

mysql_select_db("university", $test);


#table 17

echo "Table NonAcademic <br> <br>";

$sql = "SELECT * FROM NonAcademic;";

$result = mysql_query($sql, $test);


#CREATE TABLE NonAcademic (SSN INT(9) REFERENCES Staff(SSN),
# Name char (20) REFERENCES Staff(Name),
# Address char (50) REFERENCES Staff(Address), 
#Sex char (1) REFERENCES Staff(Sex),
# bDate char (10) REFERENCES Staff(bDate),

echo "SSN INT(9) " .str_repeat('&nbsp;', 10) . "Name char(20)" .str_repeat('&nbsp;', 10) . "Address char (50)" .str_repeat('&nbsp;', 10) 
. "Sex char(1)" .str_repeat('&nbsp;', 10) . "bDate char (10)" .str_repeat('&nbsp;', 10) . "<br> <br>";


while($row = mysql_fetch_array($result))
{

$ssn = $row['SSN'];
$name = $row['Name'];
$add = $row['Address'];
$sex = $row['Sex'];
$bdate = $row['bDate'];



echo $ssn . str_repeat('&nbsp;', 15). $name . str_repeat('&nbsp;', 15). $add .str_repeat('&nbsp;', 15). $sex .str_repeat('&nbsp;', 15)
. $bdate .str_repeat('&nbsp;', 15) ."<br>";

}

?>

























