<?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */

$test = mysql_connect("localhost", "root", "Gayatri1987") or die (mysql_error());

mysql_select_db("university", $test);


#Query 1

echo "Table Course <br> <br>";

$sql = "SELECT * FROM Course;";

$result = mysql_query($sql, $test);

#CREATE TABLE Course(CourseNo char (10), SecNo INT REFERENCES Section(SecNum),
# OfferingDept char (20) REFERENCES Department(DEPTNAME), 
#CreditHours INT, 
#CourseLevel char (10), 
#InstructorSSN INT (9) REFERENCES Instructor_Researcher (SSN), 
#Semester INT REFERENCES Section(Semester),
# Year INT REFERENCES Section (Year), 
#Days_Hour char (20), 
#RoomNo char (20),
# NoOfStudents INT, 


echo  "CourseNo char (10)" .str_repeat('&nbsp;', 5) . "OfferingDept char (20)" .str_repeat('&nbsp;', 5)
. "CreditHours (INT)" .str_repeat('&nbsp;', 5) . "CourseLevel char (10)" .str_repeat('&nbsp;', 5) . "InstructorSSN INT (9)" .str_repeat('&nbsp;', 5) .
"Semester (INT)" .str_repeat('&nbsp;', 5)."Year (INT)" .str_repeat('&nbsp;', 5)."Days_Hour char (20)" .str_repeat('&nbsp;', 5).
"RoomNo char (20)" .str_repeat('&nbsp;', 5)."NoOfStudents (INT)" .str_repeat('&nbsp;', 5)



."<br> <br>";


while($row = mysql_fetch_array($result))
{

$CourseNo = $row['CourseNo'];
$OfferingDept = $row['OfferingDept'];
$CreditHours = $row['CreditHours'];
$CourseLevel = $row['CourseLevel'];
$InstructorSSN = $row['InstructorSSN'];
$Semester = $row['Semester'];
$Year = $row['Year'];
$Days_Hour = $row['Days_Hour'];
$RoomNo = $row['RoomNo'];
$NoOfStudents = $row['NoOfStudents'];



echo $CourseNo . str_repeat('&nbsp;', 8). $OfferingDept . str_repeat('&nbsp;', 10). $CreditHours .str_repeat('&nbsp;', 10). $CourseLevel .str_repeat('&nbsp;', 15)
. $InstructorSSN .str_repeat('&nbsp;', 8). $Semester .str_repeat('&nbsp;', 10) . $Year.str_repeat('&nbsp;', 10) .$Days_Hour .str_repeat('&nbsp;', 10).
 $RoomNo .str_repeat('&nbsp;', 10) .$NoOfStudents.str_repeat('&nbsp;', 10)."<br>";

}

?>

























