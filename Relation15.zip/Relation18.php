<?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */

$test = mysql_connect("localhost", "root", "Gayatri1987") or die (mysql_error());

mysql_select_db("university", $test);


#table 18 



echo "Table Sport <br> <br>";

$sql = "SELECT * FROM Sport;";

$result = mysql_query($sql, $test);


#CREATE TABLE Sport (Coach char (20)
# OfficeLoc char (50), 
#Name char (20), PRIMARY KEY (OfficeLoc));

echo  "Coach char(20)" .str_repeat('&nbsp;', 5) . "OfficeLoc char (50)" .str_repeat('&nbsp;', 5) 
. "Name char (20)" .str_repeat('&nbsp;', 5) . "<br> <br>";


while($row = mysql_fetch_array($result))
{

$Coach = $row['Coach'];
$name = $row['Name'];
$Location = $row['OfficeLoc'];




echo $Coach . str_repeat('&nbsp;', 15). $name . str_repeat('&nbsp;', 15). $Location .str_repeat('&nbsp;', 15)."<br>";

}

?>

























