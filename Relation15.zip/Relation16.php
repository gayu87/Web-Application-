<?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */

$test = mysql_connect("localhost", "root", "Gayatri1987") or die (mysql_error());

mysql_select_db("university", $test);


#Query 1

echo "Table Academic <br> <br>";

$sql = "SELECT * FROM Academic;";

$result = mysql_query($sql, $test);

#CREATE TABLE Academic (SSN INT(9) REFERENCES Staff(SSN), 
# Name char (20) REFERENCES Staff(Name), 
#Address char (50) REFERENCES Staff(Address), 
#Sex char (1) REFERENCES Staff(Sex),
# bDate char (10) REFERENCES Staff(bDate), PRIMARY KEY (SSN));


echo "SSN INT(9) " .str_repeat('&nbsp;', 10) . "Name char(20)" .str_repeat('&nbsp;', 5) . "Address char (50)" .str_repeat('&nbsp;', 5) 
. "Sex char(1)" .str_repeat('&nbsp;', 5) . "bDate char (10)" .str_repeat('&nbsp;', 5) . "<br> <br>";


while($row = mysql_fetch_array($result))
{

$ssn = $row['SSN'];
$name = $row['Name'];
$add = $row['Address'];
$sex = $row['Sex'];
$bdate = $row['bDate'];



echo $ssn . str_repeat('&nbsp;', 8). $name . str_repeat('&nbsp;', 10). $add .str_repeat('&nbsp;', 10). $sex .str_repeat('&nbsp;', 15)
. $bdate .str_repeat('&nbsp;', 8) ."<br>";

}

?>

























