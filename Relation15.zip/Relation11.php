<?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */

$test = mysql_connect("localhost", "root", "Gayatri1987") or die (mysql_error());

mysql_select_db("university", $test);


#table 11 Department

echo "Table Department <br> <br>";

$sql = "SELECT * FROM Department;";

$result = mysql_query($sql, $test);

#CREATE TABLE Department(DEPTNAME char (20),
# DEPTCODE INT, 
#DEPTOFFICE char (20), 
#DEPTPHONE INT,
# DEPTCOLLEGE char (50), 


echo "DEPTNAME char (20) " .str_repeat('&nbsp;', 5) . "DEPTCODE (INT)" .str_repeat('&nbsp;', 5) . "DEPTOFFICE char (20)" .str_repeat('&nbsp;', 5) 
. "DEPTPHONE (INT)" .str_repeat('&nbsp;', 5) . "DEPTCOLLEGE char (50)" .str_repeat('&nbsp;', 5) . "<br> <br>";


while($row = mysql_fetch_array($result))
{

$DEPTNAME = $row['DEPTNAME'];
$DEPTCODE = $row['DEPTCODE'];
$DEPTOFFICE = $row['DEPTOFFICE'];
$DEPTPHONE = $row['DEPTPHONE'];
$DEPTCOLLEGE = $row['DEPTCOLLEGE'];



echo $DEPTNAME . str_repeat('&nbsp;', 8). $DEPTCODE . str_repeat('&nbsp;', 10). $DEPTOFFICE .str_repeat('&nbsp;', 10). $DEPTPHONE .str_repeat('&nbsp;', 15)
. $DEPTCOLLEGE .str_repeat('&nbsp;', 8) ."<br>";

}

?>

























