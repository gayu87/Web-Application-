<?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */

$test = mysql_connect("localhost", "root", "Gayatri1987") or die (mysql_error());

mysql_select_db("university", $test);


#Query 1

echo "Table College <br> <br>";

$sql = "SELECT * FROM College;";

$result = mysql_query($sql, $test);


#CREATE TABLE College(cName char (20), 
#Dean char (20), 
#Office char (20), PRIMARY KEY (cNAME));

echo  "cName char(20)" .str_repeat('&nbsp;', 5) . "Dean char (20)" .str_repeat('&nbsp;', 5) . "Office char(20)" .str_repeat('&nbsp;', 5) . "<br> <br>";


while($row = mysql_fetch_array($result))
{

$cName = $row['cName'];
$Dean = $row['Dean'];
$Office = $row['Office'];




echo $cName . str_repeat('&nbsp;', 8). $Dean . str_repeat('&nbsp;', 10). $Office.str_repeat('&nbsp;', 10)."<br>";

}

?>

























